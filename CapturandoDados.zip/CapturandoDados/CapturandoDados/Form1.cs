﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapturandoDados
{
    public partial class FrmDados : Form
    {
        public FrmDados()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clicou na label");
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clicou no botão");
        }

        private void lblInteiro_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clicou na label");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clicou no botão");
        }

        private void txtInteiro_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Alterou texto");
        }

        private void txtTexto_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Alterou texto");
        }

        private void txtDecimal_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Alterou texto");
        }

        private void txtBoleano_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Alterou texto");
        }

        private void lblTexto_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clicou na label");
        }

        private void lblDecimal_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clicou na label");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppTestePratico_GabrielaSena
{
    public partial class FrmCamisas : Form
    {
        public FrmCamisas()
        {
            InitializeComponent();
        }

        private void lblValorAPg_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int QtdCamisasP = int.Parse(txtCamisasP.Text);
            int QtdCamisasM = int.Parse(txtCamisasM.Text);
            int QtdCamisasG = int.Parse(txtCamisasG.Text);
            float total;

            total = QtdCamisasP * 12 + QtdCamisasM * 14 + QtdCamisasG * 22;
        }
    }
}

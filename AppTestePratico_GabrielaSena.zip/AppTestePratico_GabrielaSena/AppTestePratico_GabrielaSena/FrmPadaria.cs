﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppTestePratico_GabrielaSena
{
    public partial class FrmPadaria : Form
    {
        public FrmPadaria()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Pegar os valores na tela
            int Paes = int.Parse(txtPaes.Text);
            int Broas = int.Parse(txtBroas.Text);
            float total;


            //Fazer cálculo
            total = Broas * 1.50f + Paes * 0.12f;


            //Mostrar o resultado em uma label
            lblResultado.Text = "R$" + total;
        }
    }
}

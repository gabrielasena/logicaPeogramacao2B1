﻿namespace AppTestePratico_GabrielaSena
{
    partial class FrmPadaria
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPadaria));
            this.pnlTopo = new System.Windows.Forms.Panel();
            this.lblTopo = new System.Windows.Forms.Label();
            this.lblQtdPaes = new System.Windows.Forms.Label();
            this.lblQtdBroas = new System.Windows.Forms.Label();
            this.txtPaes = new System.Windows.Forms.TextBox();
            this.txtBroas = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblValorAPagar = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.pnlTopo.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTopo
            // 
            this.pnlTopo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(102)))), ((int)(((byte)(68)))));
            this.pnlTopo.Controls.Add(this.lblTopo);
            this.pnlTopo.Location = new System.Drawing.Point(0, 1);
            this.pnlTopo.Name = "pnlTopo";
            this.pnlTopo.Size = new System.Drawing.Size(280, 70);
            this.pnlTopo.TabIndex = 0;
            // 
            // lblTopo
            // 
            this.lblTopo.AutoSize = true;
            this.lblTopo.Font = new System.Drawing.Font("Lucida Calligraphy", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTopo.Location = new System.Drawing.Point(21, 21);
            this.lblTopo.Name = "lblTopo";
            this.lblTopo.Size = new System.Drawing.Size(129, 27);
            this.lblTopo.TabIndex = 0;
            this.lblTopo.Text = "Questão 01";
            // 
            // lblQtdPaes
            // 
            this.lblQtdPaes.AutoSize = true;
            this.lblQtdPaes.Font = new System.Drawing.Font("Lucida Bright", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdPaes.Location = new System.Drawing.Point(41, 106);
            this.lblQtdPaes.Name = "lblQtdPaes";
            this.lblQtdPaes.Size = new System.Drawing.Size(160, 18);
            this.lblQtdPaes.TabIndex = 1;
            this.lblQtdPaes.Text = "Quantidade de pães";
            // 
            // lblQtdBroas
            // 
            this.lblQtdBroas.AutoSize = true;
            this.lblQtdBroas.Font = new System.Drawing.Font("Lucida Bright", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdBroas.Location = new System.Drawing.Point(42, 204);
            this.lblQtdBroas.Name = "lblQtdBroas";
            this.lblQtdBroas.Size = new System.Drawing.Size(169, 18);
            this.lblQtdBroas.TabIndex = 2;
            this.lblQtdBroas.Text = "Quantidade de broas";
            this.lblQtdBroas.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtPaes
            // 
            this.txtPaes.Font = new System.Drawing.Font("Franklin Gothic Medium", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPaes.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtPaes.Location = new System.Drawing.Point(45, 145);
            this.txtPaes.Name = "txtPaes";
            this.txtPaes.Size = new System.Drawing.Size(198, 29);
            this.txtPaes.TabIndex = 3;
            // 
            // txtBroas
            // 
            this.txtBroas.Font = new System.Drawing.Font("Franklin Gothic Medium", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBroas.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtBroas.Location = new System.Drawing.Point(44, 245);
            this.txtBroas.Name = "txtBroas";
            this.txtBroas.Size = new System.Drawing.Size(198, 29);
            this.txtBroas.TabIndex = 4;
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(137)))), ((int)(((byte)(104)))));
            this.btnCalcular.Font = new System.Drawing.Font("Franklin Gothic Medium", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(44, 312);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(100, 35);
            this.btnCalcular.TabIndex = 5;
            this.btnCalcular.Text = "Calcule";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblValorAPagar
            // 
            this.lblValorAPagar.AutoSize = true;
            this.lblValorAPagar.Font = new System.Drawing.Font("Franklin Gothic Medium", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorAPagar.Location = new System.Drawing.Point(42, 366);
            this.lblValorAPagar.Name = "lblValorAPagar";
            this.lblValorAPagar.Size = new System.Drawing.Size(81, 17);
            this.lblValorAPagar.TabIndex = 6;
            this.lblValorAPagar.Text = "Valor a pagar";
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(46, 388);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(21, 13);
            this.lblResultado.TabIndex = 7;
            this.lblResultado.Text = "R$";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(204)))), ((int)(((byte)(178)))));
            this.ClientSize = new System.Drawing.Size(279, 450);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.lblValorAPagar);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtBroas);
            this.Controls.Add(this.txtPaes);
            this.Controls.Add(this.lblQtdBroas);
            this.Controls.Add(this.lblQtdPaes);
            this.Controls.Add(this.pnlTopo);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Form1";
            this.pnlTopo.ResumeLayout(false);
            this.pnlTopo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlTopo;
        private System.Windows.Forms.Label lblTopo;
        private System.Windows.Forms.Label lblQtdPaes;
        private System.Windows.Forms.Label lblQtdBroas;
        private System.Windows.Forms.TextBox txtPaes;
        private System.Windows.Forms.TextBox txtBroas;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblValorAPagar;
        private System.Windows.Forms.Label lblResultado;
    }
}


﻿namespace AppTestePratico_GabrielaSena
{
    partial class FrmCamisas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlTopo = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.lblQtdP = new System.Windows.Forms.Label();
            this.lblQtdM = new System.Windows.Forms.Label();
            this.lblQtdG = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.txtCamisasG = new System.Windows.Forms.TextBox();
            this.txtCamisasM = new System.Windows.Forms.TextBox();
            this.txtCamisasP = new System.Windows.Forms.TextBox();
            this.lblValorAPg = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.pnlTopo.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTopo
            // 
            this.pnlTopo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(250)))), ((int)(((byte)(237)))), ((int)(((byte)(205)))));
            this.pnlTopo.Controls.Add(this.label1);
            this.pnlTopo.Location = new System.Drawing.Point(0, 0);
            this.pnlTopo.Name = "pnlTopo";
            this.pnlTopo.Size = new System.Drawing.Size(341, 58);
            this.pnlTopo.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Calligraphy", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Exercício 02";
            // 
            // lblQtdP
            // 
            this.lblQtdP.AutoSize = true;
            this.lblQtdP.Font = new System.Drawing.Font("Franklin Gothic Medium", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdP.Location = new System.Drawing.Point(28, 89);
            this.lblQtdP.Name = "lblQtdP";
            this.lblQtdP.Size = new System.Drawing.Size(174, 20);
            this.lblQtdP.TabIndex = 1;
            this.lblQtdP.Text = "Quantidade de camisas P";
            // 
            // lblQtdM
            // 
            this.lblQtdM.AutoSize = true;
            this.lblQtdM.Font = new System.Drawing.Font("Franklin Gothic Medium", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdM.Location = new System.Drawing.Point(28, 175);
            this.lblQtdM.Name = "lblQtdM";
            this.lblQtdM.Size = new System.Drawing.Size(177, 20);
            this.lblQtdM.TabIndex = 2;
            this.lblQtdM.Text = "Quantidade de camisas M";
            // 
            // lblQtdG
            // 
            this.lblQtdG.AutoSize = true;
            this.lblQtdG.Font = new System.Drawing.Font("Franklin Gothic Medium", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdG.Location = new System.Drawing.Point(27, 253);
            this.lblQtdG.Name = "lblQtdG";
            this.lblQtdG.Size = new System.Drawing.Size(175, 20);
            this.lblQtdG.TabIndex = 3;
            this.lblQtdG.Text = "Quantidade de camisas G";
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(250)))), ((int)(((byte)(224)))));
            this.btnCalcular.Font = new System.Drawing.Font("Franklin Gothic Medium", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(32, 347);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(78, 26);
            this.btnCalcular.TabIndex = 4;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // txtCamisasG
            // 
            this.txtCamisasG.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCamisasG.Location = new System.Drawing.Point(32, 292);
            this.txtCamisasG.Name = "txtCamisasG";
            this.txtCamisasG.Size = new System.Drawing.Size(170, 26);
            this.txtCamisasG.TabIndex = 5;
            // 
            // txtCamisasM
            // 
            this.txtCamisasM.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCamisasM.Location = new System.Drawing.Point(31, 213);
            this.txtCamisasM.Name = "txtCamisasM";
            this.txtCamisasM.Size = new System.Drawing.Size(170, 26);
            this.txtCamisasM.TabIndex = 6;
            // 
            // txtCamisasP
            // 
            this.txtCamisasP.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCamisasP.Location = new System.Drawing.Point(31, 131);
            this.txtCamisasP.Name = "txtCamisasP";
            this.txtCamisasP.Size = new System.Drawing.Size(170, 26);
            this.txtCamisasP.TabIndex = 7;
            // 
            // lblValorAPg
            // 
            this.lblValorAPg.AutoSize = true;
            this.lblValorAPg.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorAPg.Location = new System.Drawing.Point(154, 349);
            this.lblValorAPg.Name = "lblValorAPg";
            this.lblValorAPg.Size = new System.Drawing.Size(121, 21);
            this.lblValorAPg.TabIndex = 8;
            this.lblValorAPg.Text = "Valor a se pagar";
            this.lblValorAPg.Click += new System.EventHandler(this.lblValorAPg_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(164, 379);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(21, 13);
            this.lblResultado.TabIndex = 9;
            this.lblResultado.Text = "R$";
            // 
            // FrmCamisas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(163)))), ((int)(((byte)(115)))));
            this.ClientSize = new System.Drawing.Size(338, 466);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.lblValorAPg);
            this.Controls.Add(this.txtCamisasP);
            this.Controls.Add(this.txtCamisasM);
            this.Controls.Add(this.txtCamisasG);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.lblQtdG);
            this.Controls.Add(this.lblQtdM);
            this.Controls.Add(this.lblQtdP);
            this.Controls.Add(this.pnlTopo);
            this.Name = "FrmCamisas";
            this.Text = "FrmCamisas";
            this.pnlTopo.ResumeLayout(false);
            this.pnlTopo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlTopo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblQtdP;
        private System.Windows.Forms.Label lblQtdM;
        private System.Windows.Forms.Label lblQtdG;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.TextBox txtCamisasG;
        private System.Windows.Forms.TextBox txtCamisasM;
        private System.Windows.Forms.TextBox txtCamisasP;
        private System.Windows.Forms.Label lblValorAPg;
        private System.Windows.Forms.Label lblResultado;
    }
}
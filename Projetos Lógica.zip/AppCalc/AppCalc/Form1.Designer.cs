﻿namespace AppCalc
{
    partial class FrmCalculadora
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmCalculadora));
            this.btnN7 = new System.Windows.Forms.Button();
            this.btnN8 = new System.Windows.Forms.Button();
            this.btnN9 = new System.Windows.Forms.Button();
            this.btnN4 = new System.Windows.Forms.Button();
            this.btnN5 = new System.Windows.Forms.Button();
            this.btnN6 = new System.Windows.Forms.Button();
            this.btnN1 = new System.Windows.Forms.Button();
            this.btnN2 = new System.Windows.Forms.Button();
            this.btnN3 = new System.Windows.Forms.Button();
            this.txtResultados = new System.Windows.Forms.TextBox();
            this.btnDivisao = new System.Windows.Forms.Button();
            this.btnSubtracao = new System.Windows.Forms.Button();
            this.btnPorcentagem = new System.Windows.Forms.Button();
            this.btnAdicao = new System.Windows.Forms.Button();
            this.btnApagarTudo = new System.Windows.Forms.Button();
            this.btnIgual = new System.Windows.Forms.Button();
            this.btnMultiplicacao = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnN7
            // 
            this.btnN7.BackColor = System.Drawing.Color.DimGray;
            this.btnN7.Location = new System.Drawing.Point(19, 129);
            this.btnN7.Name = "btnN7";
            this.btnN7.Size = new System.Drawing.Size(67, 42);
            this.btnN7.TabIndex = 0;
            this.btnN7.Text = "7";
            this.btnN7.UseVisualStyleBackColor = false;
            this.btnN7.Click += new System.EventHandler(this.btnN7_Click);
            // 
            // btnN8
            // 
            this.btnN8.BackColor = System.Drawing.Color.DimGray;
            this.btnN8.Location = new System.Drawing.Point(103, 129);
            this.btnN8.Name = "btnN8";
            this.btnN8.Size = new System.Drawing.Size(67, 42);
            this.btnN8.TabIndex = 1;
            this.btnN8.Text = "8";
            this.btnN8.UseVisualStyleBackColor = false;
            this.btnN8.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnN9
            // 
            this.btnN9.BackColor = System.Drawing.Color.DimGray;
            this.btnN9.Location = new System.Drawing.Point(187, 129);
            this.btnN9.Name = "btnN9";
            this.btnN9.Size = new System.Drawing.Size(67, 42);
            this.btnN9.TabIndex = 2;
            this.btnN9.Text = "9";
            this.btnN9.UseVisualStyleBackColor = false;
            this.btnN9.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnN4
            // 
            this.btnN4.BackColor = System.Drawing.Color.DimGray;
            this.btnN4.Location = new System.Drawing.Point(19, 215);
            this.btnN4.Name = "btnN4";
            this.btnN4.Size = new System.Drawing.Size(67, 42);
            this.btnN4.TabIndex = 3;
            this.btnN4.Text = "4";
            this.btnN4.UseVisualStyleBackColor = false;
            this.btnN4.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnN5
            // 
            this.btnN5.BackColor = System.Drawing.Color.DimGray;
            this.btnN5.Location = new System.Drawing.Point(103, 215);
            this.btnN5.Name = "btnN5";
            this.btnN5.Size = new System.Drawing.Size(67, 42);
            this.btnN5.TabIndex = 4;
            this.btnN5.Text = "5";
            this.btnN5.UseVisualStyleBackColor = false;
            this.btnN5.Click += new System.EventHandler(this.btnN5_Click);
            // 
            // btnN6
            // 
            this.btnN6.BackColor = System.Drawing.Color.DimGray;
            this.btnN6.Location = new System.Drawing.Point(187, 215);
            this.btnN6.Name = "btnN6";
            this.btnN6.Size = new System.Drawing.Size(67, 42);
            this.btnN6.TabIndex = 5;
            this.btnN6.Text = "6";
            this.btnN6.UseVisualStyleBackColor = false;
            this.btnN6.Click += new System.EventHandler(this.button6_Click);
            // 
            // btnN1
            // 
            this.btnN1.BackColor = System.Drawing.Color.DimGray;
            this.btnN1.Location = new System.Drawing.Point(19, 298);
            this.btnN1.Name = "btnN1";
            this.btnN1.Size = new System.Drawing.Size(67, 42);
            this.btnN1.TabIndex = 6;
            this.btnN1.Text = "1";
            this.btnN1.UseVisualStyleBackColor = false;
            this.btnN1.Click += new System.EventHandler(this.btnN1_Click);
            // 
            // btnN2
            // 
            this.btnN2.BackColor = System.Drawing.Color.DimGray;
            this.btnN2.Location = new System.Drawing.Point(103, 298);
            this.btnN2.Name = "btnN2";
            this.btnN2.Size = new System.Drawing.Size(67, 42);
            this.btnN2.TabIndex = 7;
            this.btnN2.Text = "2";
            this.btnN2.UseVisualStyleBackColor = false;
            this.btnN2.Click += new System.EventHandler(this.button8_Click);
            // 
            // btnN3
            // 
            this.btnN3.BackColor = System.Drawing.Color.DimGray;
            this.btnN3.Location = new System.Drawing.Point(187, 298);
            this.btnN3.Name = "btnN3";
            this.btnN3.Size = new System.Drawing.Size(67, 42);
            this.btnN3.TabIndex = 8;
            this.btnN3.Text = "3";
            this.btnN3.UseVisualStyleBackColor = false;
            this.btnN3.Click += new System.EventHandler(this.btnN3_Click);
            // 
            // txtResultados
            // 
            this.txtResultados.Font = new System.Drawing.Font("Arial Narrow", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResultados.Location = new System.Drawing.Point(12, 36);
            this.txtResultados.Name = "txtResultados";
            this.txtResultados.Size = new System.Drawing.Size(443, 50);
            this.txtResultados.TabIndex = 10;
            this.txtResultados.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtResultados.TextChanged += new System.EventHandler(this.txtResultados_TextChanged);
            // 
            // btnDivisao
            // 
            this.btnDivisao.BackColor = System.Drawing.Color.SteelBlue;
            this.btnDivisao.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDivisao.Location = new System.Drawing.Point(291, 129);
            this.btnDivisao.Name = "btnDivisao";
            this.btnDivisao.Size = new System.Drawing.Size(67, 42);
            this.btnDivisao.TabIndex = 11;
            this.btnDivisao.Text = "÷";
            this.btnDivisao.UseVisualStyleBackColor = false;
            this.btnDivisao.Click += new System.EventHandler(this.btnDivisao_Click);
            // 
            // btnSubtracao
            // 
            this.btnSubtracao.BackColor = System.Drawing.Color.SteelBlue;
            this.btnSubtracao.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubtracao.Location = new System.Drawing.Point(291, 192);
            this.btnSubtracao.Name = "btnSubtracao";
            this.btnSubtracao.Size = new System.Drawing.Size(67, 42);
            this.btnSubtracao.TabIndex = 12;
            this.btnSubtracao.Text = "-";
            this.btnSubtracao.UseVisualStyleBackColor = false;
            this.btnSubtracao.Click += new System.EventHandler(this.btnSubtracao_Click);
            // 
            // btnPorcentagem
            // 
            this.btnPorcentagem.BackColor = System.Drawing.Color.SteelBlue;
            this.btnPorcentagem.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPorcentagem.Location = new System.Drawing.Point(378, 248);
            this.btnPorcentagem.Name = "btnPorcentagem";
            this.btnPorcentagem.Size = new System.Drawing.Size(67, 42);
            this.btnPorcentagem.TabIndex = 13;
            this.btnPorcentagem.Text = "%";
            this.btnPorcentagem.UseVisualStyleBackColor = false;
            this.btnPorcentagem.Click += new System.EventHandler(this.btnPorcentagem_Click);
            // 
            // btnAdicao
            // 
            this.btnAdicao.BackColor = System.Drawing.Color.SteelBlue;
            this.btnAdicao.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicao.Location = new System.Drawing.Point(291, 248);
            this.btnAdicao.Name = "btnAdicao";
            this.btnAdicao.Size = new System.Drawing.Size(67, 92);
            this.btnAdicao.TabIndex = 14;
            this.btnAdicao.Text = "+";
            this.btnAdicao.UseVisualStyleBackColor = false;
            this.btnAdicao.Click += new System.EventHandler(this.btnAdicao_Click);
            // 
            // btnApagarTudo
            // 
            this.btnApagarTudo.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnApagarTudo.Location = new System.Drawing.Point(378, 129);
            this.btnApagarTudo.Name = "btnApagarTudo";
            this.btnApagarTudo.Size = new System.Drawing.Size(67, 42);
            this.btnApagarTudo.TabIndex = 15;
            this.btnApagarTudo.Text = "AC";
            this.btnApagarTudo.UseVisualStyleBackColor = false;
            this.btnApagarTudo.Click += new System.EventHandler(this.btnApagarTudo_Click);
            // 
            // btnIgual
            // 
            this.btnIgual.BackColor = System.Drawing.Color.SteelBlue;
            this.btnIgual.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIgual.Location = new System.Drawing.Point(378, 298);
            this.btnIgual.Name = "btnIgual";
            this.btnIgual.Size = new System.Drawing.Size(67, 42);
            this.btnIgual.TabIndex = 16;
            this.btnIgual.Text = "=";
            this.btnIgual.UseVisualStyleBackColor = false;
            this.btnIgual.Click += new System.EventHandler(this.btnIgual_Click);
            // 
            // btnMultiplicacao
            // 
            this.btnMultiplicacao.BackColor = System.Drawing.Color.SteelBlue;
            this.btnMultiplicacao.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMultiplicacao.Location = new System.Drawing.Point(378, 192);
            this.btnMultiplicacao.Name = "btnMultiplicacao";
            this.btnMultiplicacao.Size = new System.Drawing.Size(67, 42);
            this.btnMultiplicacao.TabIndex = 17;
            this.btnMultiplicacao.Text = "x";
            this.btnMultiplicacao.UseVisualStyleBackColor = false;
            this.btnMultiplicacao.Click += new System.EventHandler(this.btnMultiplicacao_Click);
            // 
            // FrmCalculadora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(467, 394);
            this.Controls.Add(this.btnMultiplicacao);
            this.Controls.Add(this.btnIgual);
            this.Controls.Add(this.btnApagarTudo);
            this.Controls.Add(this.btnAdicao);
            this.Controls.Add(this.btnPorcentagem);
            this.Controls.Add(this.btnSubtracao);
            this.Controls.Add(this.btnDivisao);
            this.Controls.Add(this.txtResultados);
            this.Controls.Add(this.btnN3);
            this.Controls.Add(this.btnN2);
            this.Controls.Add(this.btnN1);
            this.Controls.Add(this.btnN6);
            this.Controls.Add(this.btnN5);
            this.Controls.Add(this.btnN4);
            this.Controls.Add(this.btnN9);
            this.Controls.Add(this.btnN8);
            this.Controls.Add(this.btnN7);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmCalculadora";
            this.Text = "AppCalc";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnN7;
        private System.Windows.Forms.Button btnN8;
        private System.Windows.Forms.Button btnN9;
        private System.Windows.Forms.Button btnN4;
        private System.Windows.Forms.Button btnN5;
        private System.Windows.Forms.Button btnN6;
        private System.Windows.Forms.Button btnN1;
        private System.Windows.Forms.Button btnN2;
        private System.Windows.Forms.Button btnN3;
        private System.Windows.Forms.TextBox txtResultados;
        private System.Windows.Forms.Button btnDivisao;
        private System.Windows.Forms.Button btnSubtracao;
        private System.Windows.Forms.Button btnPorcentagem;
        private System.Windows.Forms.Button btnAdicao;
        private System.Windows.Forms.Button btnApagarTudo;
        private System.Windows.Forms.Button btnIgual;
        private System.Windows.Forms.Button btnMultiplicacao;
    }
}


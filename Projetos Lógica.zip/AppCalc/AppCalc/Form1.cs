﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppCalc
{
    public partial class FrmCalculadora : Form
    {
        public FrmCalculadora()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão 4");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão 8");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão 9");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão 6");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão 2");
        }

        private void btnN1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão 1");
        }

        private void btnN7_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão 7");
        }

        private void btnN5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão 5");
        }

        private void btnN3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão 3");
        }

        private void btnAdicao_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão somar");
        }

        private void btnIgual_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão igual");
        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão porcentagem");
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão multiplicação");
        }

        private void btnApagarTudo_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão para deletar tudo");
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão divisão");
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão subtrair");
        }

        private void txtResultados_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou na caixa de texto");
        }
    }
}

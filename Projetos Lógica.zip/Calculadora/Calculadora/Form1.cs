﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            int varPrimNum = int.Parse(txtPrimNum.Text);
            float varSegNum = int.Parse(txtSegNum.Text);
            float resultado;
            resultado = varPrimNum + varSegNum;
            MessageBox.Show("Soma: " + resultado);
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            int varPrimNum = int.Parse(txtPrimNum.Text);
            float varSegNum = int.Parse(txtSegNum.Text);
            float resultado;
            resultado = varPrimNum - varSegNum;
            MessageBox.Show("Subtração: " + resultado);
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            int varPrimNum = int.Parse(txtPrimNum.Text);
            float varSegNum = int.Parse(txtSegNum.Text);
            float resultado;
            resultado = varPrimNum * varSegNum;
            MessageBox.Show("Multiplicação: " + resultado);
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            int varPrimNum = int.Parse(txtPrimNum.Text);
            float varSegNum = int.Parse(txtSegNum.Text);
            float resultado;
            resultado = varPrimNum / varSegNum;
            MessageBox.Show("Divisão: " + resultado);
        }
    }
}
